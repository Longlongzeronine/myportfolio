# Virage Grow A Garden Macro
A macro for the Roblox game "Grow a Garden"

 ## Installation
 - First of all, you need to download [AutoHotKey v1.1](https://www.autohotkey.com/) (Not 2.0), and run the installer
 - Once complete, download the most recent version of the Virage Grow A Garden Macro through the most recent [GitHub Release](https://github.com/VirageRoblox/Virage-Grow-A-Garden-Macro/releases/latest)(Download source code ZIP)
 - After downloading, extract the ZIP file to your desired directory
 - Make sure your display resolution is 1920×1080 and scale is set to 100% (You can change this in your Windows settings)
 - Make sure in your Roblox settings that you selected 60 FPS and not higher
 - Before running the macro in Roblox, make sure to align your character correctly (You can watch this video for a short tutorial: ([https://www.youtube.com/watch?v=P2f-pPqFlO4](https://youtu.be/X7hhnP7Di9A))
 - You can now run the macro through the Main.ahk file in the folder

## Features
Virage Grow A Garden Macro has a couple of different features it is capable of. These include:
 - Automatic buying from all Shops, with the options to check the items you want the macro to purchase

 Discord Server: [https://discord.com/VirageMacros](https://discord.com/invite/BPPSAG8MN5)
